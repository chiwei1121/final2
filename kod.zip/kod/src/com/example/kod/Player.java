package com.example.kod;
import java.io.*;
import java.util.*;

class Player extends GamePlayer {
	public Player(String name) {
		super(name);
	}
}
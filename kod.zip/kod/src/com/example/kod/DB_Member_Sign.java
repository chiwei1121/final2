package com.example.kod;

import android.provider.BaseColumns;

public class DB_Member_Sign implements BaseColumns {
	public static final String TABLE_NAME = "Member";
	public static final String COLUMN_NAME_Account = "account";
	public static final String COLUMN_NAME_Password = "password";
	public static final String COLUMN_NAME_Name = "name";
	public static final String COLUMN_NAME_Email = "email";

	public static final String CREATE_VITAL_TABLE = "CREATE TABLE "
			+ TABLE_NAME + " (" + _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
			+ COLUMN_NAME_Account + " TEXT, " + COLUMN_NAME_Password + " TEXT, "
			+ COLUMN_NAME_Name + " TEXT, " + COLUMN_NAME_Email + " TEXT)";

	public static final String DROP_VITAL_TABLE = "DROP TABLE IF EXISTS "
			+ TABLE_NAME;

}

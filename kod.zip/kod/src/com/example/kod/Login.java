package com.example.kod;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.os.Build;

public class Login extends ActionBarActivity {
	static DB_Member_OpenHelper db_Member_Helper;
	static String acc;
	static String pwd;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
		Bundle bundle =this.getIntent().getExtras();
		acc= bundle.getString("account");
		pwd= bundle.getString("password");
		db_Member_Helper = new DB_Member_OpenHelper(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment implements OnClickListener {
		String name,email="";
		TextView person;
		Button game,out;
		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_login,
					container, false);
			person = (TextView)rootView.findViewById(R.id.Text_Person);
			game = (Button)rootView.findViewById(R.id.btn_game);
			out = (Button)rootView.findViewById(R.id.btn_logout);
			game.setOnClickListener(this);
			out.setOnClickListener(this);
			SQLiteDatabase db = db_Member_Helper.getReadableDatabase();
			Cursor c = db.query(DB_Member_Sign.TABLE_NAME, null, "account='"+acc+"' AND password='"+pwd+"'" , null, null, null, null);
			c.moveToFirst();
			name = c.getString(c.getColumnIndex(DB_Member_Sign.COLUMN_NAME_Name));
			email = c.getString(c.getColumnIndex(DB_Member_Sign.COLUMN_NAME_Email));
			Log.v("email",email);
			String inform = name+" �z�n!!!\n"+"�z��Email�O "+email;
			person.setText(inform);
			return rootView;
		}

		@Override
		public void onClick(View v) {
			if(v==game)
			{
				Intent i = new Intent();
				Bundle bundle = new Bundle();
				bundle.putString("account", acc);
				bundle.putString("password", pwd);
				i.putExtras(bundle);
				i.setClass(this.getActivity(), Game.class);
				startActivity(i);
			}
			else if(v==out)
			{
				Intent i = new Intent();
				i.setClass(this.getActivity(), MainActivity.class);
				startActivity(i);
			}
			
		}
	}

}

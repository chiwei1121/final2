package com.example.kod;

import java.util.ArrayList;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Build;

public class Game extends ActionBarActivity {
	static String acc,pwd;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game);

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
		Bundle bundle =this.getIntent().getExtras();
		acc= bundle.getString("account");
		pwd= bundle.getString("password");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.game, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment<Card> extends Fragment implements OnClickListener {

		TextView playerTextView;
		TextView continueTextView;
		TextView nameTextView;
		EditText inputName;
		Button continueButn;
		Button stayButn;
		Button hitButn;
		ArrayList<ImageView> dealerCards;
		Blackjack game;
		ArrayList<ImageView> playerCards;
		Button quitButn;
		Button okButn;
        public PlaceholderFragment() {
        }
        int getIdentifierByString (String str){
			int id = getActivity().getResources().getIdentifier(str, "id", getActivity().getPackageName());
			return id;
		}
		int getCardDrawableByString(String suit , String face){
			int id = getActivity().getResources().getIdentifier(suit + "_"+ face, "drawable",getActivity().getPackageName());
			return id;
		}	
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_game, container,
					false);
			nameTextView = (TextView) rootView.findViewById(R.id.textView2);
			playerTextView = (TextView) rootView.findViewById(R.id.textView1);
			continueTextView = (TextView) rootView.findViewById(R.id.textView3);
			inputName = (EditText) rootView.findViewById(R.id.editText1);
			okButn = (Button) rootView.findViewById(R.id.button1);
			hitButn = (Button) rootView.findViewById(R.id.button2);
			stayButn = (Button) rootView.findViewById(R.id.button3);
			continueButn = (Button) rootView.findViewById(R.id.button4);
			quitButn = (Button) rootView.findViewById(R.id.button5);
			
			dealerCards = new ArrayList<ImageView>();
			playerCards = new ArrayList<ImageView>();
			
			okButn.setOnClickListener(this);
			hitButn.setOnClickListener(this);
			stayButn.setOnClickListener(this);
			
			hitButn.setVisibility(View.INVISIBLE);
			stayButn.setVisibility(View.INVISIBLE);
			playerTextView.setVisibility(View.INVISIBLE);
			continueTextView .setVisibility(View.INVISIBLE);
			continueButn.setVisibility(View.INVISIBLE);
			quitButn.setVisibility(View.INVISIBLE);
			
			for( int i = 1 ; i <= 10; i++ )
			{
				int id1 = getIdentifierByString("imageView" + i);
				int id2;
				if(i < 10)
					id2 = getIdentifierByString("ImageView0" + i);
				else
					id2 = getIdentifierByString("ImageView" + i);
				ImageView v1 = (ImageView) rootView.findViewById(id1);
				ImageView v2 = (ImageView) rootView.findViewById(id2);
				v1.setVisibility(View.INVISIBLE);
				v2.setVisibility(View.INVISIBLE);
				dealerCards.add(v1);
				playerCards.add(v2);
			}
			return rootView;
		}
		@SuppressWarnings("unchecked")
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			if(v == okButn)
			{
				InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(inputName.getWindowToken(), 0);
				
				nameTextView.setVisibility(View.INVISIBLE);
				
				inputName.setVisibility(View.VISIBLE);
				okButn.setVisibility(View.VISIBLE);
				hitButn.setVisibility(View.VISIBLE);
				stayButn.setVisibility(View.VISIBLE);
				playerTextView.setVisibility(View.VISIBLE);
				
				game =new Blackjack(inputName.getText().toString());
				
				for(int i=0 ;  i<2 ; i++)
				{
					Animation animFadein;
					animFadein = AnimationUtils.loadAnimation(getActivity(), R.anim.abc_fade_in);
					
					dealerCards.get(i).setVisibility(View.VISIBLE);
					
					dealerCards.get(i).startAnimation(animFadein);
					
					com.example.kod.Card card = game.player.card(i);
					ImageView cardView = playerCards.get(i);
					cardView.setVisibility(View.VISIBLE);
					cardView.setImageResource(getCardDrawableByString(card.suit(),card.face()));
				}
				nameTextView.setText("Dealer's card's :");
				playerTextView.setText("Player's cards : " + game.player.point() + "points. " + game.player.state());
			} //if
			else if(v == hitButn)
			{
				int i = game.player.cardCount();
				if(i >= 10)
					return;
				ImageView cardView = playerCards.get(i);
				game.hit();
				Card card = (Card) game.player.card(i);
				cardView.setVisibility(View.VISIBLE);
				cardView.setImageResource(getCardDrawableByString(((com.example.kod.Card) card).suit(),((com.example.kod.Card) card).face()));
				playerTextView.setText("Player's Card : " + game.player.point() + "points"+ game.player.state());
				if( game.player.point() > 21)
				{
					playerTextView.setVisibility(View.VISIBLE);
					continueTextView.setVisibility(View.VISIBLE);
					continueButn.setVisibility(View.INVISIBLE);
					quitButn.setVisibility(View.INVISIBLE);
					if(v == quitButn)
						game.compete();
				}	
			}//else
			else if(v == quitButn)
			{
				Intent i = new Intent();
				Bundle bundle = new Bundle();
				bundle.putString("account", acc);
				bundle.putString("password", pwd);
				i.putExtras(bundle);
				i.setClass(this.getActivity(), Login.class);
				startActivity(i);
			}
		}
	}

}

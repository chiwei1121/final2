package com.example.kod;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.os.Build;

public class MainActivity extends ActionBarActivity {
	static DB_Member_OpenHelper db_Member_Helper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, new PlaceholderFragment())
                    .commit();
        }
        db_Member_Helper = new DB_Member_OpenHelper(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment implements OnClickListener {
    	
    	Button btnOK,btnRe;
    	EditText account,password;
    	String acc,pwd;
        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            
            btnOK = (Button)rootView.findViewById(R.id.btn_login);
            btnRe = (Button)rootView.findViewById(R.id.btn_register);
            account = (EditText)rootView.findViewById(R.id.edit_login_account);
            password = (EditText)rootView.findViewById(R.id.edit_login_password);
            btnOK.setOnClickListener(this);
            btnRe.setOnClickListener(this);
            return rootView;
        }

		@Override
		public void onClick(View v) {
			if(v==btnOK)
			{
				acc = account.getText().toString();
				pwd = password.getText().toString();
				SQLiteDatabase db = db_Member_Helper.getReadableDatabase();
				Cursor c = db.query(DB_Member_Sign.TABLE_NAME, null, "account='"+acc+"' AND password='"+pwd+"'" , null, null, null, null);
				if(c.getCount()!=0)
				{
					Intent i = new Intent();
					Bundle bundle = new Bundle();
					bundle.putString("account", acc);
					bundle.putString("password", pwd);
					i.putExtras(bundle);
					i.setClass(this.getActivity(), Login.class);
					startActivity(i);
				}
				else
					Toast.makeText(getActivity(), "�b���K�X���~!!!", Toast.LENGTH_LONG).show();
			}
			else if(v==btnRe)
			{
				Intent i = new Intent();
				i.setClass(this.getActivity(), Register.class);
				startActivity(i);
			}
			
		}
    }

}
